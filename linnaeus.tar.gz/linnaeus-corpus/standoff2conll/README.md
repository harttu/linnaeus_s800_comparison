# standoff2conll
Conversion from brat-flavored standoff to CoNLL format
